function [deltat, msdpts, sem, log_deltat, log_msdpts, alpha, DiffCoef] = MSD_2d (x, y, DT, k_choose)
% msd - calculates the msd curve for 2-D dissusion 
%   x: vector of x positions
%   y: vector of y positions

% modified from
% http://stackoverflow.com/questions/7489048/calculating-mean-squared-displacement-msd-with-matlab
tau = DT; % s time between trajectory points
data = sqrt(x.^2 + y.^2);
nData = length(data); %# number of data points
numberOfDeltaT = 40;%floor(nData/20); %# for MSD, dt should be up to 1/4 of number of data points

% Q for Abdullah, why do we need these different sized matrices of zeros of
% size N by 1?
%Idea: maybe it's setting the size of the matrix that needs to be filled
%in.
sem = zeros(numberOfDeltaT, 1); 
deltat = zeros(numberOfDeltaT, 1); 
msdpts = zeros(numberOfDeltaT, 1); 
sqdisp = zeros(numberOfDeltaT, 1); 

%# calculate msd for all deltaT's

for dt = 1:numberOfDeltaT; 
   sqdisp = (data(1+dt:end) - data(1:end-dt)).^2;
   deltat(dt) = dt * tau;
   sem(dt) = std(sqdisp) / sqrt(length(msdpts) / dt);
   msdpts(dt) = mean(sqdisp); 
end
    dp=polyfit(deltat,msdpts,1);
    DiffCoef=dp(1)./4;
    log_deltat=log10(deltat);
    log_msdpts=log10(msdpts);
    p=polyfit(log_deltat,log_msdpts,1);
    alpha=p(1);
    %figure(k_choose.*1000), hold on, plot(deltat, msdpts);
    
end