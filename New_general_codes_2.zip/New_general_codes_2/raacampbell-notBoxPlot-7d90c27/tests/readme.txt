This directory contains code for unit testing notBoxPlot
You do not need to add this directory to your path. 

To run the unit tests:

>> runtests

or 

>> table(runtests)
