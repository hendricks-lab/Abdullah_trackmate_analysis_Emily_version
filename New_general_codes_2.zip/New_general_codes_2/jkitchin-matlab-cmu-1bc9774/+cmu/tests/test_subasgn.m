clear all; clc

u = cmu.units;

a = []*u.dimensionless;
a(1) = u.m
a(2) = 3*u.dimensionless



class(a)

