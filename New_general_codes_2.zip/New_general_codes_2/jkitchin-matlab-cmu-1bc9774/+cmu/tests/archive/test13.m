u = cmu.unit.units;

a = 5*u.kg

a.as(u.lb)