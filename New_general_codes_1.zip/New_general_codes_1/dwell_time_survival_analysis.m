function [] = dwell_time_survival_analysis(dwell_time_ct,dwell_time_tr)

ct_d=dwell_time_ct;%cell2mat(dwell_time_ct);
tr_d=dwell_time_tr;%cell2mat(dwell_time_tr);

[srvl_ct,x_ct,bnd_lwr_ct,bnd_upr_ct]=ecdf(ct_d,'function','survivor','alpha',0.05,'bounds','on');
[srvl_tr,x_tr,bnd_lwr_tr,bnd_upr_tr]=ecdf(tr_d,'function','survivor','alpha',0.05,'bounds','on');


figure(987),
plot(x_ct,srvl_ct,'-','LineWidth',1,'Color','k');
hold on,
plot(x_ct,bnd_lwr_ct,'k--','LineWidth',0.5);
hold on,
plot(x_ct,bnd_upr_ct,'k--','LineWidth',0.5);
hold on,
plot(x_tr,srvl_tr,'-','LineWidth',1,'Color','g');
hold on,
plot(x_tr,bnd_lwr_tr,'g--','LineWidth',0.5);
hold on,
plot(x_tr,bnd_upr_tr,'g--','LineWidth',0.5);
hold on,
xlabel('Dwell Time (s)'); ylabel('S(x)');
publication_fig(0,0,1)

interv=10;  % bin the data over intervals (so the weibull fits the distribution)

pd_ct=fitdist(x_ct,'wbl','Censoring',0.*[1:numel(x_ct)]);
% plot(min(ct_d):interv:max(ct_d),1-cdf('wbl',min(ct_d):interv:max(ct_d),pd_ct.A,pd_ct.B),'-.k');
% legend('Weibull Fit (WT)');

[M_ct,V_ct]=wblstat(pd_ct.A,pd_ct.B);   % M = mean time
sem_dwell_t_ct=sqrt(V_ct)./sqrt(numel(ct_d));

pd_tr=fitdist(x_tr,'wbl','Censoring',0.*[1:numel(x_tr)]);
% plot(min(tr_d):interv:max(tr_d),1-cdf('wbl',min(tr_d):interv:max(tr_d),pd_tr.A,pd_tr.B),'-.g');
% legend('Weibull Fit (S421D)');

[M_tr,V_tr]=wblstat(pd_ct.A,pd_ct.B);   % M = mean time
sem_dwell_t_tr=sqrt(V_tr)./sqrt(numel(tr_d));