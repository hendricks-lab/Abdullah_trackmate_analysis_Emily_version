%% Bootstrap function - MSD
%% Abdullah R. Chaudhary
%% 05/26/2016

function [sum_x_s] = bstrp_func(x_val,N_n) 

x=x_val;
kr=0;
N=numel(x);

for ikk=1:N_n%ceil(N_n./N)
N1=randi(N,N,1);    
kr=kr+1;
x_s=x(N1);

sum_x_s{kr}=x_s;
end

x_s_1=cell2mat(sum_x_s);
