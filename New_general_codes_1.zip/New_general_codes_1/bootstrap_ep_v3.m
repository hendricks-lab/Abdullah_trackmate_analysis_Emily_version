%% Bootstrap Run Length Function - Zhu and Emily
function[avgrl] = bootstrap_ep_v3(proc_plus_run_ctrl,proc_plus_run_s421d, proc_minus_run_ctrl,proc_minus_run_s421d, nsamp)
for N=1:nsamp
    %determine the number of samples to take by the minimum number of runs
    %from all runs being analyzed
    otn=min([numel(proc_plus_run_ctrl); numel(proc_plus_run_s421d); numel(proc_minus_run_ctrl); numel(proc_minus_run_s421d)]);
    %WT plus runs
    for idx=1:otn;
    %generate a random list of numbers from 1 to the number of elements in the variable with replacement
    randi_Num=randi([1 otn]);
    proc_run_plus_tmp(idx)=proc_plus_run_ctrl(randi_Num);%using the generated random numbers to sample the data
    end
    avgrl(N)=mle(proc_run_plus_tmp,'distribution','exp');%taking the average of the sampled displacement values each iteration of the loop
    proc_run_plus_tmp=[];
    %S421D plus runs
    for idx=1:otn;
    %generate a random list of numbers from 1 to the number of elements in the variable with replacement
    randi_Num=randi([1 otn]);
    proc_run_plus_s421d_tmp(idx)=proc_plus_run_s421d(randi_Num);%using the generated random numbers to sample the data
    end
    avgrl_plus_s421d(N)=mle(proc_run_plus_s421d_tmp,'distribution','exp');%taking the average of the sampled displacement values each iteration of the loop
    proc_run_plus_s421d_tmp=[];
    %WT minus runs
    for idx=1:otn;
    %generate a random list of numbers from 1 to the number of elements in the variable with replacement
    randi_Num=randi([1 otn]);
    proc_run_minus_ctrl_tmp(idx)=-1*proc_minus_run_ctrl(randi_Num);%using the generated random numbers to sample the data
    end
    avgrl_minus_ctrl(N)=mle(proc_run_minus_ctrl_tmp,'distribution','exp');%taking the average of the sampled displacement values each iteration of the loop
    proc_run_minus_ctrl_tmp=[];
    %S421D minus runs
    for idx=1:otn;
    %generate a random list of numbers from 1 to the number of elements in the variable with replacement
    randi_Num=randi([1 otn]);
    proc_run_minus_s421d_tmp(idx)=-1*proc_minus_run_s421d(randi_Num);%using the generated random numbers to sample the data
    end
    avgrl_minus_s421d(N)=mle(proc_run_minus_s421d_tmp,'distribution','exp');%taking the average of the sampled displacement values each iteration of the loop
    proc_run_minus_s421d_tmp=[];
    if N==nsamp
    
    rng default
    figure('Name','WT Plus Bootstrapped average run length')
    boxplot(avgrl)
    figure('Name','S421D Plus Bootstrapped average run length')
    boxplot(avgrl_plus_s421d)
    figure('Name','WT Minus Bootstrapped average run length')
    boxplot(avgrl_minus_ctrl)
    figure('Name','S421D Minus Bootstrapped average run length')
    boxplot(avgrl_minus_s421d)
    
    
    
    table_run_lyso_sample=table(avgrl',avgrl_plus_s421d',avgrl_minus_ctrl',avgrl_minus_s421d');
    writetable(table_run_lyso_sample,'lyso_runs_bstrp.xlsx',"FileType","spreadsheet");
    end
end
end