%% function - load all trajectories by range

function [data_position,range_find,mean_range] = func_load_traj_by_range(position,min_disp,n_int)

kf=0;
for j=1:numel(position)
    kf=kf+1;
    range_disp(kf)=range(position{j});
    dat_pos_tim{kf}=position{j};
end

for id=1:numel(min_disp)
    jk = find(range_disp > (min_disp(id)-(n_int./2)) & range_disp < (min_disp(id)+(n_int./2)));
    jk_ind{id}=jk;
    data_position{id}=dat_pos_tim(jk);
    mean_range{id}=mean(range_disp(jk));
    range_find{id}=range_disp(jk);%-mean(range_disp(jk));
end   