function [res] = analyze_run_length_reversals_v2(time_in,position_in,min_lr,plt,k_choose)

% Its 0.03 for Early Endosomes and lysosomes

%% Savitsky Golay smoothing
span=9;    % 10 is good, 25 is good as well
pwr=6;      % 1 is good, 2 is good

position_smooth=smooth(position_in,span,'sgolay',pwr);
timek=time_in;

delp_smooth = diff(position_smooth);
delp1=delp_smooth(1:(end-1));  %First value to the second last value
delp2=delp_smooth(2:end);  %Second value to the last value
jrev_all=find(sign(delp1)~=sign(delp2)); %finds all reversals
jrev_all = jrev_all + 1;
pos_rev_all=position_in(jrev_all);
run_bw_reversal_all=diff(pos_rev_all);
j_rev_keep = find(abs(run_bw_reversal_all)>0.01);
jrev = jrev_all(j_rev_keep);  

jkr=[1,jrev',numel(position_smooth)'];

if plt==1
    figure(13849.*k_choose), subplot(1,2,1), hold on, 
    plot(timek,position_smooth);
    hold on, 
    plot(timek(jkr),position_smooth(jkr),'k.','MarkerSize',25);
    xlabel('Time (s)'); ylabel('Position (\mum)'); 
    %publication_fig(0,0,1);
    
    figure(13849.*k_choose), subplot(1,2,2), hold on, 
    plot(timek,position_in);
    hold on, 
    plot(timek(jkr),position_in(jkr),'k.','MarkerSize',25);
    xlabel('Time (s)'); ylabel('Position (\mum)'); 
    %publication_fig(0,0,1);
else
end

Nrev=numel(jkr);

Nrev=numel(jkr);

if Nrev==0,
    run_bw_reversal=NaN;
    rev_rate=NaN;
elseif Nrev==1,
    run_bw_reversal=NaN;
    rev_rate=Nrev./(timek(end)-timek(1));
else,
pos_rev=position_in(jkr);
time_rev=timek(jkr);
run_bw_reversal=diff(pos_rev);
timek_bw_reversal=diff(time_rev);
rev_rate=Nrev./(timek(end)-timek(1));

proc_run=run_bw_reversal(find(abs(run_bw_reversal)>=min_lr));
diff_run=run_bw_reversal(find(0.06<=abs(run_bw_reversal)<min_lr));
stat_run=run_bw_reversal(find(abs(run_bw_reversal)<0.01));

proc_plus_runs=proc_run(find(proc_run>0));
proc_minus_runs=proc_run(find(proc_run<0));

proc_time=timek_bw_reversal(find(abs(run_bw_reversal)>=min_lr));
diff_time=timek_bw_reversal(find(0.06<=abs(run_bw_reversal)<min_lr));
stat_time=timek_bw_reversal(find(abs(run_bw_reversal)<0.01));

proc_plus_times=proc_time(find(proc_run>0));
proc_minus_times=proc_time(find(proc_run<0));
end

res.run_bw_rev=run_bw_reversal;
res.time_bw_rev=timek_bw_reversal;
res.reversal_rate=rev_rate;
res.proc_run=proc_run;
res.diff_run=diff_run;
res.stat_run=stat_run;
res.proc_time=proc_time;
res.diff_time=diff_time;
res.stat_time=stat_time;
res.avg_velplus=mean(proc_plus_runs./proc_plus_times);
res.avg_velminus=mean(proc_minus_runs./proc_minus_times);
res.avg_lrplus=mean(proc_plus_runs);
res.avg_lrminus=mean(proc_minus_runs);

