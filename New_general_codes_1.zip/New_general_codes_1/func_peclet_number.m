%% Analyze Peclet Number:
% Pe=Heat transfer by convection./Heat transfer by conduction

function [pe]=func_peclet_number(run_bw_rev,time_bw_rev,Diffusion_coefficient)

lr=abs(run_bw_rev);
tm=time_bw_rev;

convec=(lr./tm).*lr;
avg_convec=mean(convec);

pe=avg_convec./abs(Diffusion_coefficient);